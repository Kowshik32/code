public class moneyexchanceselection extends Login
{
    void logindiplay()
    {
        System.out.println("Login succesfully");
    }
    //Taka to other currency
    public static void rupee(double taka)
    {

        double s=taka*0.7989;
        System.out.println(taka+" Taka---->"+s+" Rupee");
    }
    public static void dollar(double taka)
    {

        double s=taka*0.0098;
        System.out.println(taka+" Taka---->"+s+" Dollar");

    }
    public static void qataririal(double taka)
    {

        double s=taka*0.036;
        System.out.println(taka+" Taka---->"+s+" Qatari Rial");

    }
    public static void kuwaitidinar(double taka)
    {

        double s=taka*0.0030;
        System.out.println(taka+" Taka---->"+s+" Kuwaiti Dinar");
    }
    public static void euro(double taka)
    {

        double s=taka*0.0093;
        System.out.println(taka+" Taka---->"+s+" Euro");
    }
    public static void egyptianpound(double taka)
    {

        double s=taka*4.17;
        System.out.println(taka+" Taka---->"+s+" Egyptian Pound");
    }
    //Rupee to other currency
    public static void taka(double rupee)
    {

        double s=rupee*1.26;
        System.out.println(rupee+" Rupee---->"+s+" Taka");
    }
    public static void dollar1(double rupee)
    {

        double s=rupee*0.012;
        System.out.println(rupee+" Rupee---->"+s+" Dollar");

    }
    public static void qataririal1(double rupee)
    {

        double s=rupee*0.045;
        System.out.println(rupee+" Rupee---->"+s+" Qatari Rial");

    }
    public static void kuwaitidinar1(double rupee)
    {

        double s=rupee*0.0038;
        System.out.println(rupee+" Rupee---->"+s+" Kuwaiti Dinar");
    }
    public static void euro1(double rupee)
    {

        double s=rupee*0.012;
        System.out.println(rupee+" Rupee---->"+s+" Euro");
    }
    public static void egyptianpound1(double rupee)
    {

        double s=rupee*0.30;
        System.out.println(rupee+" Rupee---->"+s+" Egyptian Pound");
    }
    //Dollar to other currency
    public static void taka1(double Dollar)
    {

        double s=Dollar*102.56;
        System.out.println(Dollar+" Dollar---->"+s+" Taka");
    }
    public static void rupee2(double Dollar)
    {

        double s=Dollar*81.17;
        System.out.println(Dollar+" Dollar---->"+s+" Rupee");
    }
    public static void qataririal2(double Dollar)
    {

        double s=Dollar*3.64;
        System.out.println(Dollar+" Dollar---->"+s+" Qatari Rial");

    }
    public static void kuwaitidinar2(double Dollar)
    {

        double s=Dollar*0.31;
        System.out.println(Dollar+" Dollar---->"+s+" Kuwaiti Dinar");
    }
    public static void euro2(double Dollar)
    {

        double s=Dollar*0.95;
        System.out.println(Dollar+" Dollar---->"+s+" Euro");
    }
    public static void egyptianpound2(double Dollar)
    {

        double s=Dollar*24.57;
        System.out.println(Dollar+" Dollar---->"+s+" Egyptian Pound");
    }
    //Qatari Rial to other currency
    public static void taka2(double qatarriyal)
    {

        double s=qatarriyal*28.17;
        System.out.println(qatarriyal+" Qatar Riyal---->"+s+" Taka");
    }
    public static void rupee3(double qatarriyal)
    {

        double s=qatarriyal*22.30;
        System.out.println(qatarriyal+" Qatar Riyal---->"+s+" Rupee");
    }
    public static void dollar3(double qatarriyal)
    {

        double s=qatarriyal*0.27;
        System.out.println(qatarriyal+" Qatar Riyal---->"+s+" Dollar");

    }
    public static void kuwaitidinar3(double qatarriyal)
    {

        double s=qatarriyal*0.084;
        System.out.println(qatarriyal+" Qatar Riyal---->"+s+" Kuwaiti Dinar");
    }
    public static void euro3(double qatarriyal)
    {

        double s=qatarriyal*0.26;
        System.out.println(qatarriyal+" Qatar Riyal---->"+s+" Euro");
    }
    public static void egyptianpound3(double qatarriyal)
    {

        double s=qatarriyal*6.75;
        System.out.println(qatarriyal+" Qatar Riyal---->"+s+" Egyptian Pound");
    }
    //Kuwaiti Dinar to other currency
    public static void taka4(double KuwaitiDinar)
    {

        double s=KuwaitiDinar*334.30;
        System.out.println(KuwaitiDinar+" Kuwaiti Dinar---->"+s+" Taka");
    }
    public static void rupee4(double KuwaitiDinar)
    {

        double s=KuwaitiDinar*22.30;
        System.out.println(KuwaitiDinar+" Kuwaiti Dinar---->"+s+" Rupee");
    }
    public static void dollar4(double KuwaitiDinar)
    {

        double s=KuwaitiDinar*3.26;
        System.out.println(KuwaitiDinar+" Kuwaiti Dinar---->"+s+" Dollar");

    }
    public static void qataririal4(double KuwaitiDinar)
    {

        double s=KuwaitiDinar*11.87;
        System.out.println(KuwaitiDinar+" Kuwaiti Dinar---->"+s+" Qatari Rial");

    }
    public static void euro4(double KuwaitiDinar)
    {

        double s=KuwaitiDinar*3.10;
        System.out.println(KuwaitiDinar+" Kuwaiti Dinar---->"+s+" Euro");
    }
    public static void egyptianpound4(double KuwaitiDinar)
    {

        double s=KuwaitiDinar*80.04;
        System.out.println(KuwaitiDinar+" Kuwaiti Dinar---->"+s+" Egyptian Pound");
    }
    //Euro to other currency
    public static void taka5(double Euro)
    {

        double s=Euro*107.42;
        System.out.println(Euro+" Euro---->"+s+" Taka");
    }
    public static void rupee5(double Euro)
    {

        double s=Euro*85.06;
        System.out.println(Euro+" Euro---->"+s+" Rupee");
    }
    public static void dollar5(double Euro)
    {

        double s=Euro*1.05;
        System.out.println(Euro+" Euro---->"+s+" Dollar");

    }
    public static void qataririal5(double Euro)
    {

        double s=Euro*3.81;
        System.out.println(Euro+" Euro---->"+s+" Qatari Rial");

    }
    public static void kuwaitidinar5(double Euro)
    {

        double s=Euro*0.32;
        System.out.println(Euro+" Euro---->"+s+" Kuwaiti Dinar");
    }
    public static void egyptianpound5(double Euro)
    {

        double s=Euro*25.73;
        System.out.println(Euro+" Euro---->"+s+" Egyptian Pound");
    }
    //Egyptian Pound to other currency
    public static void taka6(double egyptianpound)
    {

        double s=egyptianpound*4.18;
        System.out.println(egyptianpound+" Egyptian Pound---->"+s+" Taka");
    }
    public static void rupee6(double egyptianpound)
    {

        double s=egyptianpound*3.30;
        System.out.println(egyptianpound+" Egyptian Pound---->"+s+" Rupee");
    }
    public static void dollar6(double egyptianpound)
    {

        double s=egyptianpound*0.041;
        System.out.println(egyptianpound+" Egyptian Pound---->"+s+" Dollar");

    }
    public static void qataririal6(double egyptianpound)
    {

        double s=egyptianpound*0.15;
        System.out.println(egyptianpound+" Egyptian Pound---->"+s+" Qatari Rial");

    }
    public static void kuwaitidinar6(double egyptianpound)
    {

        double s=egyptianpound*0.012;
        System.out.println(egyptianpound+" Egyptian Pound---->"+s+" Kuwaiti Dinar");
    }
    public static void euro6(double egyptianpound)
    {

        double s=egyptianpound*0.039;
        System.out.println(egyptianpound+" Egyptian Pound---->"+s+" Euro");
    }

}

